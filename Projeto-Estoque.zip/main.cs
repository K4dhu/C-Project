using System;
using System.Collections.Generic;

public class Produto
{
    public string Nome { get; set; }
    public decimal Preco { get; set; }
    public string Tamanho { get; set; }
    public int QuantidadeEstoque { get; set; } = 0;

    public Produto(string nome, decimal preco, string tamanho)
    {
        Nome = nome;
        Preco = preco;
        Tamanho = tamanho;
    }

    public override string ToString() =>
        $"Nome: {Nome}, Preço: {Preco:C}, Tamanho: {Tamanho}, Quantidade: {QuantidadeEstoque}";
}

public class ControleEstoque
{
    private readonly List<Produto> produtos = new();

    public void AdicionarProduto(Produto produto) => produtos.Add(produto);

    public void ListarProdutos() => produtos.ForEach(p => Console.WriteLine(p));

    public void RemoverProduto(string nome)
    {
        Produto produto = produtos.Find(p => p.Nome == nome);
        if (produto != null) produtos.Remove(produto);
    }

    public void AlterarEstoque(string nome, int quantidade)
    {
        Produto produto = produtos.Find(p => p.Nome == nome);
        if (produto != null) produto.QuantidadeEstoque += quantidade;
    }
}

class Program
{
    static void Main()
    {
        ControleEstoque estoque = new();
        int opcao;

        do
        {
            Console.WriteLine("O que você deseja fazer?: ");

            Console.WriteLine("[1]Novo: ");
            Console.WriteLine("[2]Listar: ");
            Console.WriteLine("[3]Remover: ");
            Console.WriteLine("[4]Entrada Estoque: ");
            Console.WriteLine("[5] Saida Estoque: ");
            Console.WriteLine("[0]Sair");

            opcao = int.Parse(Console.ReadLine());

            if (opcao == 1)
            {
                Console.Write("Nome: "); string nome = Console.ReadLine();
                Console.Write("Preço: "); decimal preco = decimal.Parse(Console.ReadLine());
                Console.Write("Tamanho: "); string tamanho = Console.ReadLine();
                estoque.AdicionarProduto(new Produto(nome, preco, tamanho));
            }
            else if (opcao == 2) estoque.ListarProdutos();
            else if (opcao == 3) { Console.Write("Nome: "); estoque.RemoverProduto(Console.ReadLine()); }
            else if (opcao == 4 || opcao == 5)
            {
                Console.Write("Nome: "); string nome = Console.ReadLine();
                Console.Write("Quantidade: "); int quantidade = int.Parse(Console.ReadLine()) * (opcao == 4 ? 1 : -1);
                estoque.AlterarEstoque(nome, quantidade);
            }

        } while (opcao != 0);
    }
}
